<template>
  <div>

    <p>Contador: {{ contador }}</p>
    <button @click="diminuirContador">Diminuir Contador</button>
    <button @click="aumentarContador">Aumentar Contador</button>
  </div>


  <div>
    <button @click="toggleTexto">Mostre o texto agora 🐒</button>
    <p v-if="visivel">Eu não aguento mais tentar</p>
  </div>
  <div>
    <input v-model="nome" placeholder="Digite seu nome"/>
    <p>Bem-vindo {{ nome }}.</p>
  </div>

  <div>
    <input v-model="novoItem" placeholder="Digite um novo item"/>
    <button @click="adicionarItem">Adicionar Item</button>
    <ul>
      <li v-for="(item, index) in itens" :key="index" @click="removerItem(index)">
        {{ item }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      contador: 0,
      visivel: false,
      nome: "",
      itens: ["item1", "item2", "item3"],
      novoItem: ""
    };
  },
  methods: {
    diminuirContador() {
      this.contador--;
    },
    aumentarContador() {
      this.contador++;
    },
    toggleTexto() {
      this.visivel = !this.visivel;
    },
    adicionarItem() {
      if (this.novoItem.trim() !== "") {
        this.itens.push(this.novoItem.trim());
        this.novoItem = ""; // Limpa o campo de entrada após adicionar
      }
    },
    removerItem(index) {
      this.itens.splice(index, 1);
    }
  }
};
</script>

<style scoped>
</style>
